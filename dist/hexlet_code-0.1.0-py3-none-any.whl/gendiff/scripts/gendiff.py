def main():
    import argparse
    parser = argparse.ArgumentParser(description='Compares two configuration files and shows a difference.')
    parser.add_arguments('first_file', help='First file to compare')
    parser.add_arguments('second_file, help='Second file to compare')
    args = parser.parse_args()

if __name__ == '__main__':
    main()
